package br.senac.go;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


/**
 * Unit test for simple App.

 */
@SpringBootTest
public class AppTest {
    @Test
    void contextLoads() {
    }
}
